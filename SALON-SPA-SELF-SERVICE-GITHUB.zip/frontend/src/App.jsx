import React, { useState } from "react";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showRegister, setShowRegister] = useState(false);
  const [userName, setUserName] = useState("");
  const [selectedService, setSelectedService] = useState(null);
  const [showBooking, setShowBooking] = useState(false);
  const [selectedStylist, setSelectedStylist] = useState(null);
  const [bookingConfirmed, setBookingConfirmed] = useState(false);
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedSlot, setSelectedSlot] = useState(null);

  const services = [
    {
        id: 1,
        name: "Hair Styling",
        price: "₹1200",
        description: "Professional hair styling and finishing.",
        icon: "💇‍♀️",
    },
    {
        id: 2,
        name: "Hair Cut",
        price: "₹800",
        description: "Professional haircut and styling.",
        icon: "✂️",
    },
    {
        id: 3,
        name: "Glow Facial",
        price: "₹1500",
        description: "Refreshing facial treatment for glowing skin.",
        icon: "✨",
    },
    {
        id: 4,
        name: "Deep Cleansing Facial",
        price: "₹1800",
        description: "Deep cleansing facial treatment for healthy skin.",
        icon: "🧖‍♀️",
    },
    {
        id: 5,
        name: "Head Massage",
        price: "₹700",
        description: "Relaxing head massage for stress relief.",
        icon: "💆‍♀️",
    },
    {
        id: 6,
        name: "Body Massage",
        price: "₹2000",
        description: "A relaxing full body massage experience.",
        icon: "🌸",
    },
    {
        id: 7,
        name: "Manicure",
        price: "₹600",
        description: "Complete nail care with a relaxing treatment.",
        icon: "💅",
    },
    {
        id: 8,
        name: "Pedicure",
        price: "₹800",
        description: "Relaxing foot care and professional nail treatment.",
        icon: "🦶",
    },
    {
        id: 9,
        name: "Party Makeup",
        price: "₹2500",
        description: "Professional makeup for parties and special occasions.",
        icon: "💄",
    },
    {
        id: 10,
        name: "Bridal Makeup",
        price: "₹6000",
        description: "Professional bridal makeup service.",
        icon: "👰‍♀️",
    },
];

  const stylists = [
    {
        id: 1,
        name: "Priya",
        specialty: "Hair Styling",
        experience: "6 Years Experience",
        rating: "4.9",
        icon: "👩‍🎨",
    },
    {
        id: 2,
        name: "Sneha",
        specialty: "Skin & Spa",
        experience: "5 Years Experience",
        rating: "4.8",
        icon: "💆‍♀️",
    },
];
  const timeSlots = [
  "10:00 AM",
  "11:00 AM",
  "12:00 PM",
  "02:00 PM",
  "03:00 PM",
  "04:00 PM",
  "05:00 PM",
  "06:00 PM",
];
  if (!isLoggedIn) {
    return (
      <div style={styles.authPage}>

        <div style={styles.authCard}>

          <div style={styles.authLogo}>
            Glow & Grace
          </div>

          <p style={styles.smallTitle}>
            SALON & SPA SELF-SERVICE
          </p>

          {!showRegister ? (
            <>
              <h1 style={styles.authTitle}>
                Welcome Back
              </h1>

              <p style={styles.authText}>
                Login to manage your salon and spa appointments.
              </p>

              <input
                style={styles.authInput}
                type="email"
                placeholder="Email Address"
              />

              <input
                style={styles.authInput}
                type="password"
                placeholder="Password"
              />

              <button
                style={styles.authButton}
                onClick={() => {
                  setUserName("Customer");
                  setIsLoggedIn(true);
                }}
              >
                Login
              </button>

              <p style={styles.authSwitch}>
                Don't have an account?
              </p>

              <button
                style={styles.switchButton}
                onClick={() => setShowRegister(true)}
              >
                Create New Account
              </button>
            </>
          ) : (
            <>
              <h1 style={styles.authTitle}>
                Create Account
              </h1>

              <p style={styles.authText}>
                Register to book and manage your appointments.
              </p>

              <input
                style={styles.authInput}
                type="text"
                placeholder="Full Name"
                onChange={(event) =>
                  setUserName(event.target.value)
                }
              />

              <input
                style={styles.authInput}
                type="email"
                placeholder="Email Address"
              />

              <input
                style={styles.authInput}
                type="tel"
                placeholder="Phone Number"
              />

              <input
                style={styles.authInput}
                type="password"
                placeholder="Create Password"
              />

              <button
                style={styles.authButton}
                onClick={() => {
                  setIsLoggedIn(true);
                }}
              >
                Create Account
              </button>

              <p style={styles.authSwitch}>
                Already have an account?
              </p>

              <button
                style={styles.switchButton}
                onClick={() => setShowRegister(false)}
              >
                Back to Login
              </button>
            </>
          )}

        </div>

      </div>
    );
  }
  return (
    <div style={styles.page}>

      {/* NAVBAR */}
      <nav style={styles.navbar}>
        <div style={styles.logo}>
          Glow & Grace
        </div>

        <div style={styles.navLinks}>
          <a href="#home" style={styles.navLink}>Home</a>
          <a href="#services" style={styles.navLink}>Services</a>
          <a href="#about" style={styles.navLink}>About</a>
          <a href="#contact" style={styles.navLink}>Contact</a>
          <a href="#services" style={styles.navButton}>
            Book Now
          </a>
        </div>
      </nav>

      {/* HERO */}
      <section id="home" style={styles.hero}>
        <div style={styles.heroContent}>

          <p style={styles.smallTitle}>
            WELCOME TO GLOW & GRACE
          </p>

          <h1 style={styles.heroTitle}>
            Your Beauty.
            <br />
            Your Relaxation.
            <br />
            <span style={styles.heroHighlight}>
              Your Experience.
            </span>
          </h1>

          <p style={styles.heroText}>
            Book your salon and spa experience with ease.
            Choose your service, select your preferred stylist,
            and reserve your appointment.
          </p>

          <button
            style={styles.primaryButton}
            onClick={() => {
              document
                .getElementById("services")
                ?.scrollIntoView({ behavior: "smooth" });
            }}
          >
            Explore Services →
          </button>

        </div>

        <div style={styles.heroCard}>
          <div style={styles.heroEmoji}>
            💆‍♀️
          </div>

          <h2>Relax. Refresh. Renew.
          </h2>

          <p>
            Professional salon and spa services
            designed around you.
          </p>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" style={styles.section}>

        <p style={styles.smallTitle}>
          OUR SERVICES
        </p>

        <h2 style={styles.sectionTitle}>
          Choose Your Perfect Experience
        </h2>

        <p style={styles.sectionText}>
          Browse our services and select the treatment
          that suits you best.
        </p>

        <div style={styles.serviceGrid}>

          {services.map((service) => (
            <div
              key={service.id}
              style={{
                ...styles.serviceCard,
                ...(selectedService === service.name
                  ? styles.selectedService
                  : {}),
              }}
            >

              <div style={styles.serviceIcon}>
                {service.icon}
              </div>

              <h3 style={styles.serviceName}>
                {service.name}
              </h3>

              <p style={styles.serviceDescription}>
                {service.description}
              </p>

              <p style={styles.servicePrice}>
                {service.price}
              </p>

              <button
                style={styles.primaryButton}
                onClick={() => {
                  setSelectedService(service.name);
                  setSelectedStylist(null);
                  setBookingConfirmed(false);
                  setShowBooking(true);

                  setTimeout(() => {
                    document
                      .getElementById("booking")
                      ?.scrollIntoView({
                        behavior: "smooth",
                      });
                  }, 100);
                }}
              >
                Select Service →
              </button>

            </div>
          ))}

        </div>
      </section>

      {/* BOOKING SECTION */}
      {showBooking && !bookingConfirmed && (
        <section id="booking" style={styles.bookingSection}>

          <p style={styles.smallTitle}>
            BOOK YOUR APPOINTMENT
          </p>

          <h2 style={styles.sectionTitle}>
            Choose Your Stylist
          </h2>

          <p style={styles.selectedServiceText}>
            Selected Service:{" "}
            <strong>{selectedService}</strong>
          </p>

          {/* STYLISTS */}
          <div style={styles.stylistGrid}>

            {stylists.map((stylist) => (
              <div
                key={stylist.id}
                style={{
                  ...styles.stylistCard,
                  ...(selectedStylist === stylist.name
                    ? styles.selectedStylist
                    : {}),
                }}
                onClick={() =>
                  setSelectedStylist(stylist.name)
                }
              >

                <div style={styles.stylistIcon}>
                  {stylist.icon}
                </div>

                <h3>
                  {stylist.name}
                </h3>

                <p style={styles.stylistSpecialty}>
                  {stylist.specialty}
                </p>

                <p>
                  {stylist.experience}
                </p>

                <p style={styles.rating}>
                  ⭐ {stylist.rating}
                </p>

                <button
                  style={styles.stylistButton}
                  onClick={(event) => {
                    event.stopPropagation();
                    setSelectedStylist(stylist.name);
                  }}
                >
                  {selectedStylist === stylist.name
                    ? "Selected ✓"
                    : "Select Stylist"}
                </button>

              </div>
            ))}

          </div>

          {/* APPOINTMENT DETAILS */}
          {selectedStylist && (
            <div style={styles.appointmentDetails}>

              <div style={styles.selectedStylistPanel}>

                <div>
                  <p style={styles.smallTitleWhite}>
                    SELECTED STYLIST
                  </p>

                  <h3 style={styles.selectedStylistName}>
                    {selectedStylist}
                  </h3>

                  <p>
                    Your preferred stylist has been selected.
                  </p>
                </div>

              </div>

              <p style={styles.smallTitle}>
                APPOINTMENT DETAILS
              </p>

              <h2 style={styles.sectionTitle}>
                Select Date & Time
              </h2>

              <div style={styles.formGrid}>

  <input
    style={styles.input}
    type="text"
    placeholder="Your Name"
  />

  <input
    style={styles.input}
    type="tel"
    placeholder="Phone Number"
  />

  <input
    style={styles.input}
    type="date"
    value={selectedDate}
    onChange={(event) => {
      setSelectedDate(event.target.value);
      setSelectedSlot(null);
    }}
  />

</div>

{selectedDate && (
  <div style={styles.slotSection}>

    <p style={styles.smallTitle}>
      AVAILABLE TIME SLOTS
    </p>

    <h3>
      Choose your preferred appointment time
    </h3>

    <div style={styles.slotGrid}>

      {timeSlots.map((slot) => (
        <button
          key={slot}
          style={{
            ...styles.slotButton,
            ...(selectedSlot === slot
              ? styles.selectedSlot
              : {}),
          }}
          onClick={() => setSelectedSlot(slot)}
        >
          {slot}
        </button>
      ))}

    </div>

    {selectedSlot && (
      <div style={styles.selectedSlotPanel}>

        <strong>
          Selected Time:
        </strong>{" "}
        {selectedSlot}

      </div>
    )}

  </div>
)}

            <button
  style={{
    ...styles.primaryButton,
    opacity:
      selectedDate && selectedSlot
        ? 1
        : 0.5,
  }}
  disabled={!selectedDate || !selectedSlot}
  onClick={async () => {
    try {
        // Find the selected service
        const service = services.find(
            (item) => item.name === selectedService
        );

        // Find the selected stylist
        const stylist = stylists.find(
            (item) => item.name === selectedStylist
        );

        if (!service || !stylist) {
            alert("Please select a valid service and stylist.");
            return;
        }

        // Convert selected time from "12:00 PM" to "12:00:00"
        const [time, modifier] = selectedSlot.split(" ");
        let [hours, minutes] = time.split(":").map(Number);

        if (modifier === "PM" && hours !== 12) {
            hours += 12;
        }

        if (modifier === "AM" && hours === 12) {
            hours = 0;
        }

        const startTime =
            `${String(hours).padStart(2, "0")}:` +
            `${String(minutes).padStart(2, "0")}:00`;

        // Send booking to Express backend
        const response = await fetch(
            "http://localhost:5000/api/appointments",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                
              },
                body: JSON.stringify({
                    customer_id: 1,
                    staff_id: stylist.id,
                    service_id: service.id,
                    appointment_date: selectedDate,
                    start_time: startTime,
                }),
            }
        );

        const data = await response.json();

        if (!response.ok) {
            throw new Error(
                data.message || "Failed to create appointment"
            );
        }

        console.log("Appointment created:", data);

        // Show the existing confirmation screen
        setBookingConfirmed(true);

    } catch (error) {
        console.error("Booking error:", error);
       setBookingConfirmed(true);
    }
}}
>
  Confirm Appointment
</button>  

            </div>
          )}

        </section>
      )}

      {/* CONFIRMATION */}
      {bookingConfirmed && (
        <section style={styles.confirmationSection}>

          <div style={styles.confirmationBox}>

            <div style={styles.confirmationIcon}>
              ✓
            </div>

            <p style={styles.smallTitle}>
              BOOKING CONFIRMED
            </p>

            <h2 style={styles.confirmationTitle}>
              Your appointment is confirmed!
            </h2>

            <p>
              Thank you for choosing{" "}
              <strong>Glow & Grace</strong>.
            </p>

            <div style={styles.confirmationDetails}>

              <p>
                <strong>Service:</strong>{" "}
                {selectedService}
              </p>

              <p>
                <strong>Stylist:</strong>{" "}
                {selectedStylist}
              </p>

              <p>
                <strong>Status:</strong>{" "}
                Confirmed
              </p>

            </div>

            <button
              style={styles.primaryButton}
              onClick={() => {
                setBookingConfirmed(false);
                setShowBooking(false);
                setSelectedService(null);
                setSelectedStylist(null);

                document
                  .getElementById("services")
                  ?.scrollIntoView({
                    behavior: "smooth",
                  });
              }}
            >
              Back to Services
            </button>

          </div>

        </section>
      )}

      {/* ABOUT */}
      <section id="about" style={styles.aboutSection}>

        <p style={styles.smallTitle}>
          ABOUT US
        </p>

        <h2 style={styles.sectionTitle}>
          Beauty & Wellness, Simplified
        </h2>

        <p style={styles.sectionText}>
          Glow & Grace provides a convenient self-service
          salon and spa experience where customers can
          browse services, select their preferred stylist,
          and book appointments easily.
        </p>

      </section>

      {/* CONTACT */}
      <section id="contact" style={styles.contactSection}>

        <p style={styles.smallTitle}>
          CONTACT
        </p>

        <h2 style={styles.sectionTitle}>
          We Are Here For You
        </h2>

        <p>
          📞 +91 98765 43210
        </p>

        <p>
          ✉️ glowandgrace@example.com
        </p>

      </section>

      {/* FOOTER */}
      <footer style={styles.footer}>
        <p>
          © 2026 Glow & Grace. All rights reserved.
        </p>
      </footer>

    </div>
  );
}

const styles = {
    authPage: {
    minHeight: "100vh",
    background: "#f8e9e5",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: "30px",
    boxSizing: "border-box",
  },

  authCard: {
    width: "420px",
    maxWidth: "100%",
    background: "#ffffff",
    padding: "45px",
    borderRadius: "25px",
    textAlign: "center",
    boxShadow: "0 15px 45px rgba(80, 50, 50, 0.12)",
    boxSizing: "border-box",
  },

  authLogo: {
    fontSize: "30px",
    fontWeight: "800",
    color: "#9b5964",
    marginBottom: "15px",
  },

   authTitle: {
    fontSize: "32px",
    margin: "15px 0 10px",
    color: "#4a3035",
},
  authText: {
    color: "#6d5d5d",
    lineHeight: "1.6",
    marginBottom: "25px",
  },

  authInput: {
    width: "100%",
    boxSizing: "border-box",
    padding: "14px",
    marginBottom: "15px",
    border: "1px solid #ddc9c5",
    borderRadius: "10px",
    fontSize: "15px",
    outline: "none",
  },

  authButton: {
    width: "100%",
    border: "none",
    background: "#b76e79",
    color: "#ffffff",
    padding: "14px",
    borderRadius: "25px",
    fontWeight: "700",
    cursor: "pointer",
    fontSize: "16px",
    marginTop: "5px",
  },

  authSwitch: {
    color: "#6d5d5d",
    marginTop: "25px",
    marginBottom: "8px",
  },

  switchButton: {
    border: "none",
    background: "transparent",
    color: "#b76e79",
    fontWeight: "700",
    cursor: "pointer",
    fontSize: "15px",
  },
  slotSection: {
  marginTop: "35px",
  padding: "25px",
  background: "#fffaf8",
  borderRadius: "18px",
},

slotGrid: {
  display: "grid",
  gridTemplateColumns: "repeat(4, 1fr)",
  gap: "12px",
  maxWidth: "700px",
  margin: "25px auto",
},

slotButton: {
  padding: "13px",
  border: "1px solid #d9bfc0",
  background: "#ffffff",
  color: "#302525",
  borderRadius: "10px",
  cursor: "pointer",
  fontWeight: "600",
},

selectedSlot: {
  background: "#b76e79",
  color: "#ffffff",
  border: "1px solid #b76e79",
},

selectedSlotPanel: {
  marginTop: "20px",
  padding: "15px",
  background: "#f4e1e2",
  color: "#7d4d55",
  borderRadius: "10px",
  fontSize: "16px",
},

  page: {
    margin: 0,
    fontFamily: "Arial, sans-serif",
    color: "#302525",
    background: "#fffaf8",
  },

  navbar: {
    position: "sticky",
    top: 0,
    zIndex: 10,
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "18px 7%",
    background: "#ffffff",
    borderBottom: "1px solid #ead9d5",
  },

  logo: {
    fontSize: "25px",
    fontWeight: "800",
    color: "#9b5964",
  },

  navLinks: {
    display: "flex",
    alignItems: "center",
    gap: "25px",
  },

  navLink: {
    textDecoration: "none",
    color: "#302525",
    fontWeight: "600",
  },

  navButton: {
    textDecoration: "none",
    background: "#b76e79",
    color: "#ffffff",
    padding: "10px 18px",
    borderRadius: "22px",
    fontWeight: "700",
  },

  hero: {
    minHeight: "550px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "70px 8%",
    gap: "50px",
    background: "#f8e9e5",
  },

  heroContent: {
    maxWidth: "650px",
  },

  smallTitle: {
    color: "#b76e79",
    fontWeight: "800",
    letterSpacing: "2px",
    fontSize: "13px",
  },

  smallTitleWhite: {
    color: "#f4d8d5",
    fontWeight: "800",
    letterSpacing: "2px",
    fontSize: "13px",
  },

  heroTitle: {
    fontSize: "52px",
    lineHeight: "1.1",
    margin: "15px 0",
    color: "#4a3035",
  },

  heroHighlight: {
    color: "#b76e79",
    color: "#8f3f4b",
  },

  heroText: {
    fontSize: "18px",
    lineHeight: "1.7",
    color: "#645656",
    maxWidth: "580px",
  },

  heroCard: {
    width: "330px",
    minHeight: "300px",
    borderRadius: "30px",
    background: "#ffffff",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    textAlign: "center",
    padding: "30px",
    boxShadow: "0 15px 40px rgba(80, 50, 50, 0.10)",
  },

  heroEmoji: {
    fontSize: "80px",
  },

  primaryButton: {
    marginTop: "18px",
    border: "none",
    background: "#b76e79",
    color: "#ffffff",
    padding: "13px 24px",
    borderRadius: "25px",
    fontWeight: "700",
    cursor: "pointer",
    fontSize: "15px",
  },

  section: {
    padding: "80px 8%",
    textAlign: "center",
  },

  sectionTitle: {
    fontSize: "36px",
    margin: "10px 0",
    color: "#4a3035",
  },

  sectionText: {
    maxWidth: "700px",
    margin: "0 auto 35px",
    color: "#6d5d5d",
    lineHeight: "1.7",
  },

  serviceGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(3, 1fr)",
    gap: "25px",
    marginTop: "40px",
  },

  serviceCard: {
    background: "#ffffff",
    border: "1px solid #ead9d5",
    borderRadius: "20px",
    padding: "30px",
    textAlign: "center",
    boxShadow: "0 8px 25px rgba(80, 50, 50, 0.05)",
  },

  selectedService: {
    border: "2px solid #b76e79",
  },

  serviceIcon: {
    fontSize: "55px",
    marginBottom: "15px",
  },

  serviceName: {
    fontSize: "22px",
  },

  serviceDescription: {
    color: "#6d5d5d",
    lineHeight: "1.6",
    minHeight: "50px",
  },

  servicePrice: {
    fontSize: "22px",
    fontWeight: "800",
    color: "#b76e79",
  },

  bookingSection: {
    padding: "80px 8%",
    background: "#f8eeeb",
    textAlign: "center",
  },

  selectedServiceText: {
    fontSize: "17px",
    color: "#645656",
  },

  stylistGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(4, 1fr)",
    gap: "20px",
    marginTop: "35px",
  },

  stylistCard: {
    background: "#ffffff",
    border: "1px solid #ead9d5",
    borderRadius: "18px",
    padding: "25px",
    textAlign: "center",
    cursor: "pointer",
    boxShadow: "0 8px 25px rgba(80, 50, 50, 0.05)",
  },

  selectedStylist: {
    border: "2px solid #b76e79",
    background: "#fff7f5",
  },

  stylistIcon: {
    width: "75px",
    height: "75px",
    margin: "0 auto 15px",
    borderRadius: "50%",
    background: "#f4e1e2",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "38px",
  },

  stylistSpecialty: {
    color: "#6d5d5d",
    minHeight: "45px",
  },

  rating: {
    fontWeight: "700",
    color: "#b76e79",
  },

  stylistButton: {
    marginTop: "10px",
    border: "none",
    background: "#f4e1e2",
    color: "#9b5964",
    padding: "10px 16px",
    borderRadius: "22px",
    fontWeight: "700",
    cursor: "pointer",
  },

  selectedStylistPanel: {
    marginTop: "35px",
    padding: "25px",
    background: "#302525",
    color: "#ffffff",
    borderRadius: "18px",
    textAlign: "left",
  },

  selectedStylistName: {
    fontSize: "25px",
    margin: "5px 0",
  },

  appointmentDetails: {
    marginTop: "40px",
    padding: "40px",
    background: "#ffffff",
    borderRadius: "20px",
    textAlign: "center",
  },

  formGrid: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: "18px",
    maxWidth: "700px",
    margin: "30px auto",
  },

  input: {
    width: "100%",
    boxSizing: "border-box",
    padding: "14px",
    border: "1px solid #ddc9c5",
    borderRadius: "10px",
    fontSize: "15px",
    outline: "none",
  },

  confirmationSection: {
    padding: "90px 8%",
    background: "#f8eeeb",
    textAlign: "center",
  },

  confirmationBox: {
    maxWidth: "650px",
    margin: "0 auto",
    padding: "45px",
    background: "#ffffff",
    borderRadius: "25px",
    boxShadow: "0 15px 40px rgba(80, 50, 50, 0.10)",
  },

  confirmationIcon: {
    width: "70px",
    height: "70px",
    margin: "0 auto 20px",
    borderRadius: "50%",
    background: "#b76e79",
    color: "#ffffff",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "38px",
    fontWeight: "800",
  },

  confirmationTitle: {
    fontSize: "30px",
  },

  confirmationDetails: {
    marginTop: "25px",
    padding: "20px",
    background: "#f8eeeb",
    borderRadius: "15px",
    textAlign: "left",
  },

  aboutSection: {
    padding: "80px 8%",
    textAlign: "center",
    background: "#ffffff",
  },

  contactSection: {
    padding: "70px 8%",
    textAlign: "center",
    background: "#f8e9e5",
  },

  footer: {
    padding: "25px",
    textAlign: "center",
    background: "#302525",
    color: "#ffffff",
  },
};

export default App;