
const express = require("express");
const pool = require("../config/db");

const router = express.Router();

// Get all appointments
router.get("/", async (req, res) => {
    try {
        const [rows] = await pool.query(`
            SELECT
                a.appointment_id,
                a.appointment_date,
                a.start_time,
                a.end_time,
                a.status,
                a.total_amount,
                u.name AS customer_name,
                su.name AS staff_name
            FROM appointments a
            JOIN customers 
                ON a.customer_id = c.customer_id
            JOIN users u
                ON c.user_id = u.user_id
            JOIN staff st
                ON a.staff_id = st.staff_id
            JOIN users su
                ON st.user_id = su.user_id
            ORDER BY a.appointment_date, a.start_time
        `);

        res.json(rows);
    } catch (error) {
        console.error("Error fetching appointments:", error);

        res.status(500).json({
            message: "Failed to fetch appointments"
        });
    }
});


// Create a new appointment
router.post("/", async (req, res) => {
    try {
       const {
    customer_id,
    staff_id,
    service_id,
    appointment_date,
    start_time
} = req.body;






       if (
    !customer_id ||
    !staff_id ||
    !service_id ||
    !appointment_date ||
    !start_time
) {
    return res.status(400).json({
        message: "All booking details are required"
    });
}

        // Get service details
        const [services] = await pool.query(
            `
            SELECT price, duration_minutes
            FROM services
            WHERE service_id = ? AND status = 'ACTIVE'
            `,
            [service_id]
        );

        if (services.length === 0) {
            return res.status(404).json({
                message: "Service not found"
            });
        }

        const service = services[0];

        // Calculate end time
        const [timeParts] = await pool.query(
            `SELECT ADDTIME(?, SEC_TO_TIME(? * 60)) AS end_time`,
            [start_time, service.duration_minutes]
        );

        const end_time = timeParts[0].end_time;

        // Create appointment
        const [appointmentResult] = await pool.query(
            `
            INSERT INTO appointments
            (
                customer_id,
                staff_id,
                appointment_date,
                start_time,
                end_time,
                status,
                total_amount
            )
            VALUES (?, ?, ?, ?, ?, 'CONFIRMED', ?)
            `,
            [
                customer_id,
                staff_id,
                appointment_date,
                start_time,
                end_time,
                service.price
            ]
        );

        const appointment_id = appointmentResult.insertId;

        // Add service to appointment
        await pool.query(
            `
            INSERT INTO appointment_services
            (
                appointment_id,
                service_id,
                price,
                duration_minutes
            )
            VALUES (?, ?, ?, ?)
            `,
            [
                appointment_id,
                service_id,
                service.price,
                service.duration_minutes
            ]
        );

        res.status(201).json({
            message: "Appointment created successfully",
            appointment_id,
            appointment_date,
            start_time,
            end_time,
            total_amount: service.price,
            status: "PENDING"
        });

    } catch (error) {
        console.error("Error creating appointment:", error);

        res.status(500).json({
            message: "Failed to create appointment"
        });
    }
});


module.exports = router;