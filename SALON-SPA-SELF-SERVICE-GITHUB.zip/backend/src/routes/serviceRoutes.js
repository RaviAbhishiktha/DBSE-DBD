const express = require("express");
const pool = require("../config/db");

const router = express.Router();

router.get("/", async (req, res) => {
    try {
        const [rows] = await pool.query(`
            SELECT
                s.service_id,
                s.service_name,
                s.description,
                s.duration_minutes,
                s.price,
                c.category_name
            FROM services s
            JOIN service_categories c
                ON s.category_id = c.category_id
            WHERE s.status = 'ACTIVE'
            ORDER BY s.service_id
        `);

        res.json(rows);
    } catch (error) {
        console.error("Error fetching services:", error);

        res.status(500).json({
            message: "Failed to fetch services"
        });
    }
});

module.exports = router;