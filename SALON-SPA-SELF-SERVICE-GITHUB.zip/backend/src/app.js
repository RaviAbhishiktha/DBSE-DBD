const express = require("express");
const cors = require("cors");

const serviceRoutes = require("./routes/serviceRoutes");
const appointmentRoutes = require("./routes/appointmentRoutes");
const authRoutes = require("./routes/authRoutes");

const app = express();

app.use(cors());
app.use(express.json());

// Service APIs
app.use("/api/services", serviceRoutes);

// Appointment APIs
app.use("/api/appointments", appointmentRoutes);
app.use("/api/auth", authRoutes);

// Home route
app.get("/", (req, res) => {
    res.json({
        message: "Glow & Grace Salon & Spa API is running!"
    });
});

// Health check
app.get("/api/health", (req, res) => {
    res.json({
        status: "OK",
        message: "Backend is healthy"
    });
});

module.exports = app;